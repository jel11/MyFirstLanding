# 🍊 OMNIFOOD - Landing Page

> Современный landing page для сервиса доставки здорового питания

![Angular](https://img.shields.io/badge/Angular-17-DD0031?style=flat&logo=angular)
![SCSS](https://img.shields.io/badge/SCSS-latest-CC6699?style=flat&logo=sass)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6?style=flat&logo=typescript)

---

## 📋 Содержание

- [О проекте](#о-проекте)
- [Технологии](#технологии)
- [Установка](#установка)
- [Запуск](#запуск)
- [Структура проекта](#структура-проекта)
- [Особенности](#особенности)
- [Скриншоты](#скриншоты)

---

## 🎯 О проекте

Omnifood - это учебный проект landing page для сервиса доставки здорового питания. Проект создан в рамках учебной практики с применением современных веб-технологий и best practices.

### Цели проекта

- ✅ SEO-оптимизация
- ✅ Использование только `rem` единиц
- ✅ Обеспечение безопасности
- ✅ Плавные hover эффекты
- ✅ Современная цветовая палитра
- ✅ Angular standalone компоненты

---

## 🛠 Технологии

### Frontend

- **Angular 17** - фреймворк
- **TypeScript 5.0** - язык программирования
- **SCSS** - препроцессор CSS
- **Standalone Components** - новый подход Angular

### Инструменты

- **Angular CLI** - сборка и разработка
- **Webpack** - module bundler
- **ESLint** - линтер кода
- **Prettier** - форматирование кода

---

## 📦 Установка

### Предварительные требования

Убедитесь, что у вас установлены:

- [Node.js](https://nodejs.org/) >= 18.x
- [npm](https://www.npmjs.com/) >= 9.x
- [Angular CLI](https://angular.io/cli) >= 17.x

### Установка Angular CLI (если не установлен)

```bash
npm install -g @angular/cli
```

### Клонирование репозитория

```bash
git clone https://github.com/yourusername/omnifood-landing.git
cd omnifood-landing
```

### Установка зависимостей

```bash
npm install
```

---

## 🚀 Запуск

### Development сервер

Запустите локальный сервер разработки:

```bash
ng serve
```

Приложение будет доступно по адресу: `http://localhost:4200/`

### Production build

Создайте оптимизированную сборку для production:

```bash
ng build --configuration production
```

Файлы будут созданы в директории `dist/`

### Запуск тестов

```bash
# Unit тесты
ng test

# E2E тесты
ng e2e

# Code coverage
ng test --code-coverage
```

---

## 📁 Структура проекта

```
omnifood-landing/
│
├── src/
│   ├── app/
│   │   ├── components/
│   │   │   ├── header/
│   │   │   │   ├── header.component.ts
│   │   │   │   ├── header.component.html
│   │   │   │   └── header.component.scss
│   │   │   ├── hero/
│   │   │   ├── featured-in/
│   │   │   ├── how-it-works/
│   │   │   ├── meals/
│   │   │   ├── testimonials/
│   │   │   ├── pricing/
│   │   │   ├── cta/
│   │   │   └── footer/
│   │   │
│   │   └── app.component.ts
│   │
│   ├── styles/
│   │   ├── _variables.scss
│   │   ├── _mixins.scss
│   │   └── styles.scss
│   │
│   ├── assets/
│   │   ├── images/
│   │   └── icons/
│   │
│   └── index.html
│
├── angular.json
├── package.json
└── README.md
```

---

## ✨ Особенности

### SEO Оптимизация

- ✅ Семантический HTML5
- ✅ Meta теги (title, description, Open Graph)
- ✅ Правильная иерархия заголовков (H1-H6)
- ✅ Alt теги для всех изображений
- ✅ Структурированные данные Schema.org

### Адаптивность

- ✅ Mobile-first подход
- ✅ Breakpoints: 576px, 768px, 992px, 1200px
- ✅ Адаптивные изображения (picture + srcset)
- ✅ Гибкая типографика

### Производительность

- ✅ Lazy loading изображений
- ✅ WebP формат с PNG/JPG fallback
- ✅ Tree-shaking (удаление неиспользуемого кода)
- ✅ Минификация CSS/JS
- ✅ Gzip compression

### Accessibility (A11y)

- ✅ ARIA атрибуты
- ✅ Keyboard navigation
- ✅ Focus-visible стили
- ✅ Reduced motion support
- ✅ WCAG 2.1 уровень AA

### Безопасность

- ✅ Angular sanitization (XSS защита)
- ✅ Content Security Policy (CSP)
- ✅ HTTPS only
- ✅ Валидация форм

---

## 🎨 Цветовая палитра

```scss
// Основные цвета
$primary-color: #e67e22;      // Оранжевый
$primary-dark: #cf711f;       // Тёмный оранжевый
$primary-light: #fdf2e9;      // Светлый персиковый

// Нейтральные
$text-dark: #333333;          // Основной текст
$text-medium: #555555;        // Вторичный текст
$white: #ffffff;              // Белый

// Акценты
$accent-green: #51cf66;       // Зелёный
$accent-red: #ff6b6b;         // Красный
```

---

## 📱 Скриншоты

### Desktop

![Desktop Hero](docs/screenshots/desktop-hero.png)
![Desktop Meals](docs/screenshots/desktop-meals.png)

### Mobile

![Mobile Hero](docs/screenshots/mobile-hero.png)
![Mobile Menu](docs/screenshots/mobile-menu.png)

---

## 🗺 Roadmap

### День 1 ✅ (Завершено)
- [x] Header с навигацией
- [x] Hero секция
- [x] Базовые стили

### День 2 (В процессе)
- [ ] Featured-in секция
- [ ] How it works секция

### День 3 (Планируется)
- [ ] Meals секция
- [ ] Diets список

### День 4 (Планируется)
- [ ] Testimonials секция
- [ ] Gallery секция

### День 5 (Планируется)
- [ ] Pricing секция
- [ ] CTA секция
- [ ] Footer

---

## 📝 Документация

Подробная документация доступна в файле [DOCUMENTATION.md](DOCUMENTATION.md)

### Полезные ссылки

- [Angular Documentation](https://angular.io/docs)
- [SCSS Guide](https://sass-lang.com/guide)
- [Figma Макет](https://www.figma.com/design/chKizc8asXLGLgTLkoGi5C/OnnifoodApp)

---

## 🤝 Contributing

Проект создан в учебных целях. Pull requests приветствуются!

1. Fork проекта
2. Создайте feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit изменения (`git commit -m 'Add some AmazingFeature'`)
4. Push в branch (`git push origin feature/AmazingFeature`)
5. Откройте Pull Request

---

## 📄 Лицензия

Этот проект создан в учебных целях.

---

## 👨‍💻 Автор

**Ваше Имя**

- GitHub: [@yourusername](https://github.com/yourusername)
- Email: your.email@example.com

---

## 🙏 Благодарности

- Макет: [Jonas Schmedtmann - Omnifood](https://omnifood.dev/)
- Angular Team
- Open Source Community

---

**⭐ Если проект понравился, поставьте звезду!**
