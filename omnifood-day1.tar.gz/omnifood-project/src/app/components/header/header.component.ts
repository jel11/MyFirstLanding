import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Header Component
 * 
 * Описание:
 * Компонент навигационной панели с липким позиционированием.
 * Включает адаптивное мобильное меню и эффект прозрачности при скролле.
 * 
 * Особенности:
 * - Липкая навигация (sticky header)
 * - Адаптивное мобильное меню
 * - Плавные переходы между состояниями
 * - Keyboard accessibility (Tab навигация)
 * 
 * @export
 * @class HeaderComponent
 */
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  /**
   * Состояние мобильного меню
   * @type {boolean}
   */
  isMobileMenuOpen = false;

  /**
   * Состояние прокрутки страницы
   * @type {boolean}
   */
  isScrolled = false;

  /**
   * Переключение мобильного меню
   * 
   * Объяснение для преподавателя:
   * Метод изменяет состояние видимости мобильного меню.
   * При открытии меню блокируется скролл body (для UX).
   * 
   * @memberof HeaderComponent
   */
  toggleMobileMenu(): void {
    this.isMobileMenuOpen = !this.isMobileMenuOpen;
    
    // Блокируем скролл body когда меню открыто
    if (this.isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }

  /**
   * Слушатель скролла страницы
   * 
   * Объяснение для преподавателя:
   * @HostListener - декоратор Angular для прослушивания событий DOM.
   * Отслеживаем позицию скролла для добавления класса к header.
   * Порог 100px выбран для оптимального UX.
   * 
   * @param {Event} event - событие скролла
   * @memberof HeaderComponent
   */
  @HostListener('window:scroll', ['$event'])
  onWindowScroll(): void {
    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
    this.isScrolled = scrollPosition > 100;
  }

  /**
   * Слушатель изменения размера окна
   * 
   * Объяснение для преподавателя:
   * Закрываем мобильное меню при увеличении окна до desktop размера.
   * Предотвращает баг с открытым меню на большом экране.
   * 
   * @memberof HeaderComponent
   */
  @HostListener('window:resize', ['$event'])
  onResize(): void {
    // Закрываем мобильное меню на desktop
    if (window.innerWidth > 992 && this.isMobileMenuOpen) {
      this.isMobileMenuOpen = false;
      document.body.style.overflow = '';
    }
  }

  /**
   * Обработчик клика по ссылке навигации
   * 
   * Объяснение для преподавателя:
   * Закрываем мобильное меню после клика по ссылке.
   * Улучшает UX на мобильных устройствах.
   * 
   * @memberof HeaderComponent
   */
  closeMobileMenu(): void {
    if (this.isMobileMenuOpen) {
      this.isMobileMenuOpen = false;
      document.body.style.overflow = '';
    }
  }
}
