import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Hero Component
 * 
 * Описание:
 * Главная секция лендинга с призывом к действию (Call-to-Action).
 * Содержит заголовок, описание, CTA кнопки и social proof.
 * 
 * SEO особенности:
 * - H1 заголовок с ключевыми словами
 * - Alt теги для всех изображений
 * - Семантическая структура HTML
 * - Lazy loading для изображений (кроме hero)
 * 
 * Безопасность:
 * - Использование Angular sanitization для контента
 * - Валидация всех внешних ссылок
 * 
 * @export
 * @class HeroComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-hero',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.scss']
})
export class HeroComponent implements OnInit {
  
  /**
   * Данные для аватарок клиентов
   * 
   * Объяснение для преподавателя:
   * Массив с путями к изображениям клиентов.
   * В production это будет загружаться из API.
   * 
   * @type {string[]}
   * @memberof HeroComponent
   */
  customerAvatars: string[] = [
    'assets/images/customers/customer-1.jpg',
    'assets/images/customers/customer-2.jpg',
    'assets/images/customers/customer-3.jpg',
    'assets/images/customers/customer-4.jpg',
    'assets/images/customers/customer-5.jpg',
    'assets/images/customers/customer-6.jpg'
  ];

  /**
   * Счётчик доставленных обедов
   * 
   * Объяснение для преподавателя:
   * Используется для анимации подсчёта при загрузке страницы.
   * Форматируется с разделителями тысяч для читабельности.
   * 
   * @type {number}
   * @memberof HeroComponent
   */
  deliveredMealsCount = 250000;

  /**
   * Lifecycle hook: инициализация компонента
   * 
   * Объяснение для преподавателя:
   * OnInit - выполняется после создания компонента.
   * Здесь можно добавить загрузку данных, инициализацию анимаций.
   * 
   * @memberof HeroComponent
   */
  ngOnInit(): void {
    // Анимация появления hero секции
    this.animateOnLoad();
  }

  /**
   * Анимация появления секции
   * 
   * Объяснение для преподавателя:
   * Добавляем класс для CSS анимации с небольшой задержкой.
   * Улучшает UX при загрузке страницы.
   * 
   * @private
   * @memberof HeroComponent
   */
  private animateOnLoad(): void {
    // Задержка для плавного появления после загрузки
    setTimeout(() => {
      const heroElement = document.querySelector('.hero');
      if (heroElement) {
        heroElement.classList.add('hero--loaded');
      }
    }, 100);
  }

  /**
   * Форматирование числа с разделителями
   * 
   * Объяснение для преподавателя:
   * Утилита для форматирования больших чисел (250000 → "250,000").
   * Используется для отображения количества доставок.
   * 
   * @param {number} num - число для форматирования
   * @returns {string} - отформатированное число
   * @memberof HeroComponent
   */
  formatNumber(num: number): string {
    return num.toLocaleString('ru-RU');
  }

  /**
   * Обработчик клика по CTA кнопке
   * 
   * Объяснение для преподавателя:
   * Метод для отслеживания кликов (аналитика).
   * Можно интегрировать с Google Analytics или Яндекс.Метрикой.
   * 
   * @param {string} buttonType - тип кнопки (primary/secondary)
   * @memberof HeroComponent
   */
  onCtaClick(buttonType: string): void {
    // Здесь можно добавить отправку события в аналитику
    console.log(`CTA button clicked: ${buttonType}`);
    
    // Пример интеграции с аналитикой:
    // this.analyticsService.trackEvent('cta_click', { button_type: buttonType });
  }
}
