import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

// Импорт компонентов
import { HeaderComponent } from './components/header/header.component';
import { HeroComponent } from './components/hero/hero.component';

/**
 * App Component (Главный компонент)
 * 
 * Описание:
 * Корневой компонент приложения, объединяющий все секции лендинга.
 * Использует standalone подход (без NgModule).
 * 
 * Структура:
 * - Header (навигация)
 * - Hero (главная секция)
 * - Featured-in (логотипы компаний) - День 2
 * - How it works (как это работает) - День 2
 * - Meals (блюда) - День 3
 * - Testimonials (отзывы) - День 4
 * - Gallery (галерея) - День 4
 * - Pricing (цены) - День 5
 * - CTA (призыв к действию) - День 5
 * - Footer (подвал) - День 5
 * 
 * @export
 * @class AppComponent
 */
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    HeroComponent,
    // FeaturedInComponent,     // День 2
    // HowItWorksComponent,     // День 2
    // MealsComponent,          // День 3
    // TestimonialsComponent,   // День 4
    // GalleryComponent,        // День 4
    // PricingComponent,        // День 5
    // CtaComponent,            // День 5
    // FooterComponent          // День 5
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  /**
   * Заголовок приложения
   * Используется в meta тегах для SEO
   * 
   * @type {string}
   * @memberof AppComponent
   */
  title = 'Omnifood - Здоровое питание с доставкой';

  /**
   * Описание приложения
   * Используется в meta тегах для SEO
   * 
   * @type {string}
   * @memberof AppComponent
   */
  description = 'Персонализированное здоровое питание с доставкой 365 дней в году. Подберите диету, которая подходит именно вам!';
}
