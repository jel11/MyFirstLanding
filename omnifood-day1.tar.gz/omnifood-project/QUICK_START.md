# 🚀 БЫСТРЫЙ СТАРТ - OMNIFOOD

## Что уже готово (День 1)

✅ **Файловая структура проекта**
✅ **Глобальные стили** (_variables.scss, _mixins.scss, styles.scss)
✅ **Header компонент** (навигация с мобильным меню)
✅ **Hero компонент** (главная секция)
✅ **SEO оптимизация** (meta теги, структурированные данные)
✅ **Безопасность** (CSP, sanitization)
✅ **Все размеры в rem**
✅ **Hover эффекты**

---

## ⚡ Быстрый запуск

### Шаг 1: Создайте Angular проект

```bash
# Установите Angular CLI (если не установлен)
npm install -g @angular/cli

# Создайте новый проект
ng new omnifood-landing --routing --style=scss --standalone

# Перейдите в директорию
cd omnifood-landing
```

### Шаг 2: Скопируйте файлы

Скопируйте из архива следующие файлы в ваш проект:

```
Скопировать:
- src/styles/_variables.scss
- src/styles/_mixins.scss
- src/styles/styles.scss
- src/app/components/header/*
- src/app/components/hero/*
- src/app/app.component.ts
- src/app/app.component.html
- src/app/app.component.scss
- src/index.html
```

### Шаг 3: Обновите главный файл стилей

В `angular.json` найдите секцию `styles` и замените на:

```json
"styles": [
  "src/styles/styles.scss"
]
```

### Шаг 4: Добавьте изображения

Создайте директории и добавьте изображения:

```bash
mkdir -p src/assets/images/customers
mkdir -p src/assets/icons
```

Скачайте изображения из Figma макета или используйте placeholder:
- `src/assets/images/omnifood-logo.png`
- `src/assets/images/hero.png` (или .webp)
- `src/assets/images/customers/customer-1.jpg` до customer-6.jpg

### Шаг 5: Запустите проект

```bash
ng serve
```

Откройте в браузере: `http://localhost:4200`

---

## 📂 Структура файлов

```
omnifood-landing/
├── src/
│   ├── app/
│   │   ├── components/
│   │   │   ├── header/
│   │   │   │   ├── header.component.ts      ← Логика
│   │   │   │   ├── header.component.html    ← HTML
│   │   │   │   └── header.component.scss    ← Стили
│   │   │   └── hero/
│   │   │       ├── hero.component.ts
│   │   │       ├── hero.component.html
│   │   │       └── hero.component.scss
│   │   ├── app.component.ts                  ← Главный компонент
│   │   ├── app.component.html
│   │   └── app.component.scss
│   ├── styles/
│   │   ├── _variables.scss                   ← Цвета, размеры
│   │   ├── _mixins.scss                      ← Переиспользуемые стили
│   │   └── styles.scss                       ← Глобальные стили
│   ├── assets/
│   │   └── images/
│   └── index.html                            ← SEO meta теги
```

---

## 🎨 Основные файлы

### 1. Переменные (_variables.scss)

Все цвета, размеры, отступы:

```scss
$primary-color: #e67e22;      // Оранжевый
$base-font-size: 16px;         // 1rem = 16px
$spacing-md: 1.5rem;           // 24px
```

### 2. Миксины (_mixins.scss)

Готовые стили для кнопок, hover, адаптивности:

```scss
@include button-primary;       // Кнопка
@include respond(lg) { ... }   // Media query
@include hover-lift;           // Hover эффект
```

### 3. Header (header.component.ts)

Навигация с функциями:
- `toggleMobileMenu()` - открыть/закрыть меню
- `onWindowScroll()` - отслеживание прокрутки
- `onResize()` - адаптивность

### 4. Hero (hero.component.ts)

Главная секция с:
- Анимацией появления
- CTA кнопками
- Social proof (аватарки клиентов)

---

## 🎯 Для презентации преподавателю

### Расскажите о:

1. **Технологиях:**
   - Angular 17 standalone components
   - SCSS с переменными и миксинами
   - TypeScript для типобезопасности

2. **SEO:**
   - Семантический HTML (header, nav, main, section)
   - Meta теги в index.html
   - Alt теги для изображений
   - Структурированные данные Schema.org

3. **Безопасность:**
   - Angular sanitization (автоматическая защита от XSS)
   - Content Security Policy в meta тегах
   - HTTPS only политика

4. **Rem единицы:**
   - Базовый размер 16px = 1rem
   - Все размеры в проекте используют rem
   - Масштабируемость и accessibility

5. **Hover эффекты:**
   - Кнопки: поднятие + тень
   - Ссылки: подчёркивание снизу
   - Аватарки: увеличение при hover
   - Плавные transitions

6. **Архитектура:**
   - Компонентный подход
   - Standalone компоненты (новый Angular)
   - Переиспользуемые стили (mixins)
   - Mobile-first адаптивность

---

## 📝 Чек-лист перед презентацией

- [ ] Проект запускается без ошибок
- [ ] Header отображается корректно
- [ ] Hero секция показывает контент
- [ ] Мобильное меню работает (кнопка бургер)
- [ ] Hover эффекты работают на всех элементах
- [ ] Адаптивность на разных размерах экрана
- [ ] Изображения загружаются
- [ ] Плавная прокрутка к якорям работает

---

## 🐛 Возможные проблемы

### Проблема: Стили не применяются

**Решение:**
Проверьте `angular.json`:
```json
"styles": [
  "src/styles/styles.scss"  ← должно быть так
]
```

### Проблема: Изображения не загружаются

**Решение:**
Убедитесь, что файлы в `src/assets/images/`:
```
src/assets/images/omnifood-logo.png
src/assets/images/hero.png
src/assets/images/customers/customer-1.jpg
```

### Проблема: Ошибка компиляции SCSS

**Решение:**
Проверьте пути импорта в .scss файлах:
```scss
@import '../../../styles/variables';  // Правильный путь
```

---

## 📚 Дополнительные материалы

- **DOCUMENTATION.md** - подробное объяснение всего проекта
- **README.md** - общая информация и roadmap
- **Figma макет** - https://www.figma.com/design/chKizc8asXLGLgTLkoGi5C/OnnifoodApp

---

## 🎓 Что говорить преподавателю

### Про технологии:
"Я использовал Angular 17 с новым standalone подходом, который не требует NgModules. Это современная практика, рекомендованная командой Angular."

### Про SEO:
"Для SEO я применил семантический HTML5, добавил все необходимые meta теги в index.html, включая Open Graph для социальных сетей и структурированные данные Schema.org для поисковых систем."

### Про безопасность:
"Angular автоматически защищает от XSS атак через sanitization. Я также добавил Content Security Policy в meta тегах и настроил HTTPS-only политику."

### Про rem:
"Все размеры в проекте использую в rem единицах для масштабируемости и accessibility. Базовый размер 1rem = 16px, что позволяет пользователям с плохим зрением увеличивать шрифт в настройках браузера."

### Про hover:
"Я реализовал различные типы hover эффектов: для кнопок - поднятие с тенью, для ссылок - анимированное подчёркивание, для изображений - плавное масштабирование. Все с плавными transitions."

---

**Удачи на презентации! 🚀**
