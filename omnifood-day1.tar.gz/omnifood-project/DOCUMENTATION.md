# OMNIFOOD - Учебная практика
## Подробное объяснение проекта для преподавателя

---

## 📋 ОГЛАВЛЕНИЕ

1. [Обзор проекта](#обзор-проекта)
2. [Технологический стек](#технологический-стек)
3. [Архитектура проекта](#архитектура-проекта)
4. [SEO оптимизация](#seo-оптимизация)
5. [Безопасность](#безопасность)
6. [Использование rem единиц](#использование-rem-единиц)
7. [Hover эффекты](#hover-эффекты)
8. [День 1: Header и Hero](#день-1-header-и-hero)
9. [Производительность](#производительность)
10. [Accessibility (Доступность)](#accessibility)

---

## ОБЗОР ПРОЕКТА

### Описание
Omnifood - это landing page для сервиса доставки здорового питания. Проект создан в рамках учебной практики с применением современных веб-технологий и best practices.

### Цели проекта
1. ✅ Создать SEO-оптимизированный лендинг
2. ✅ Использовать только rem единицы для масштабируемости
3. ✅ Обеспечить безопасность приложения
4. ✅ Добавить плавные hover эффекты
5. ✅ Применить современную цветовую палитру
6. ✅ Использовать Angular standalone компоненты

---

## ТЕХНОЛОГИЧЕСКИЙ СТЕК

### Frontend Framework
- **Angular 17** (latest) - современный фреймворк от Google
- **Standalone Components** - новый подход без NgModules

### Стилизация
- **SCSS** - препроцессор CSS с переменными и миксинами
- **Mobile-First подход** - адаптивность с мобильных устройств

### Сборка и оптимизация
- **Angular CLI** - инструмент для сборки и разработки
- **Webpack** (под капотом Angular) - сборщик модулей

---

## АРХИТЕКТУРА ПРОЕКТА

### Структура файлов

```
omnifood-project/
├── src/
│   ├── app/
│   │   ├── components/           # Компоненты приложения
│   │   │   ├── header/
│   │   │   │   ├── header.component.ts
│   │   │   │   ├── header.component.html
│   │   │   │   └── header.component.scss
│   │   │   ├── hero/
│   │   │   ├── featured-in/
│   │   │   ├── how-it-works/
│   │   │   ├── meals/
│   │   │   ├── testimonials/
│   │   │   ├── pricing/
│   │   │   ├── cta/
│   │   │   └── footer/
│   │   └── app.component.ts      # Главный компонент
│   │
│   ├── styles/                    # Глобальные стили
│   │   ├── _variables.scss        # Переменные (цвета, размеры)
│   │   ├── _mixins.scss           # Переиспользуемые стили
│   │   └── styles.scss            # Базовые стили
│   │
│   ├── assets/                    # Статические файлы
│   │   ├── images/
│   │   └── icons/
│   │
│   └── index.html                 # Главный HTML файл
```

### Почему такая структура?

**Компонентный подход:**
- Каждая секция - отдельный компонент
- Легко поддерживать и тестировать
- Переиспользуемость кода

**Standalone компоненты:**
```typescript
@Component({
  selector: 'app-header',
  standalone: true,          // ← Новый подход Angular
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
```

**Преимущества:**
- Меньше boilerplate кода
- Быстрее загрузка (tree-shaking)
- Проще понимать зависимости

---

## SEO ОПТИМИЗАЦИЯ

### 1. Семантический HTML

**Использование правильных тегов:**

```html
<!-- ❌ ПЛОХО -->
<div class="header">
  <div class="nav">...</div>
</div>

<!-- ✅ ХОРОШО -->
<header class="header" role="banner">
  <nav class="header__nav" role="navigation">...</nav>
</header>
```

**Наши семантические теги:**
- `<header>` - шапка сайта
- `<nav>` - навигация
- `<main>` - основной контент
- `<section>` - секции контента
- `<article>` - статья/карточка
- `<footer>` - подвал сайта

### 2. Заголовки (H1-H6)

**Правильная иерархия:**

```html
<!-- Только ОДИН H1 на странице -->
<h1 class="hero__title">
  Здоровое питание с доставкой каждый день
</h1>

<!-- H2 для секций -->
<h2>Как это работает</h2>

<!-- H3 для подзаголовков -->
<h3>Шаг 1: Выберите план</h3>
```

### 3. Alt теги для изображений

**Описательные альтернативные тексты:**

```html
<!-- ❌ ПЛОХО -->
<img src="hero.jpg" alt="image">

<!-- ✅ ХОРОШО -->
<img 
  src="hero.jpg" 
  alt="Женщина наслаждается здоровой едой, блюда на столе, красивая сервировка"
  width="800"
  height="600"
  loading="eager"
/>
```

**Почему важно:**
- Поисковики индексируют alt теги
- Accessibility для слабовидящих
- Отображается при загрузке изображения

### 4. Meta теги

В `index.html` добавляем:

```html
<!-- SEO базовые теги -->
<title>Omnifood - Здоровое питание с доставкой</title>
<meta name="description" content="Персонализированное здоровое питание с доставкой 365 дней в году. Подберите диету, которая подходит именно вам!">
<meta name="keywords" content="здоровое питание, доставка еды, диета, правильное питание">

<!-- Open Graph для социальных сетей -->
<meta property="og:title" content="Omnifood - Здоровое питание">
<meta property="og:description" content="Персонализированное здоровое питание с доставкой">
<meta property="og:image" content="/assets/images/og-image.jpg">
<meta property="og:url" content="https://omnifood.example.com">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Omnifood - Здоровое питание">
```

### 5. Структурированные данные (Schema.org)

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FoodEstablishment",
  "name": "Omnifood",
  "description": "Здоровое питание с доставкой",
  "url": "https://omnifood.example.com",
  "telephone": "+7-999-123-45-67",
  "address": {
    "@type": "PostalAddress",
    "addressCountry": "RU"
  }
}
</script>
```

---

## БЕЗОПАСНОСТЬ

### 1. Angular встроенная защита

**XSS (Cross-Site Scripting) защита:**

Angular автоматически sanitizes (очищает) весь контент:

```typescript
// ✅ БЕЗОПАСНО - Angular автоматически экранирует
<p>{{ userInput }}</p>

// ⚠️ ОПАСНО - обход sanitization
<div [innerHTML]="dangerousHtml"></div>
```

**Использование DomSanitizer:**

```typescript
import { DomSanitizer } from '@angular/platform-browser';

constructor(private sanitizer: DomSanitizer) {}

getSafeHtml(html: string) {
  return this.sanitizer.sanitize(SecurityContext.HTML, html);
}
```

### 2. HTTPS only

В `index.html`:

```html
<!-- Принудительное использование HTTPS -->
<meta http-equiv="Content-Security-Policy" 
      content="upgrade-insecure-requests">
```

### 3. Content Security Policy (CSP)

```html
<meta http-equiv="Content-Security-Policy" 
      content="default-src 'self'; 
               script-src 'self' 'unsafe-inline'; 
               style-src 'self' 'unsafe-inline'; 
               img-src 'self' data: https:;">
```

**Что это означает:**
- `default-src 'self'` - загружать ресурсы только с нашего домена
- `script-src` - разрешённые источники скриптов
- `style-src` - разрешённые источники стилей
- `img-src` - разрешённые источники изображений

### 4. Валидация форм

```typescript
import { FormBuilder, Validators } from '@angular/forms';

this.ctaForm = this.fb.group({
  email: ['', [
    Validators.required,
    Validators.email,
    Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)
  ]],
  name: ['', [
    Validators.required,
    Validators.minLength(2),
    Validators.maxLength(50)
  ]]
});
```

---

## ИСПОЛЬЗОВАНИЕ REM ЕДИНИЦ

### Почему rem?

**Преимущества:**
1. ✅ Масштабируемость - пользователь может изменить размер шрифта в браузере
2. ✅ Accessibility - помогает людям с плохим зрением
3. ✅ Консистентность - все размеры относительно базового

### Система rem в проекте

**Базовая настройка:**

```scss
// _variables.scss
$base-font-size: 16px;  // 1rem = 16px

html {
  font-size: $base-font-size;
}
```

**Таблица конверсии:**

| px  | rem   | Использование          |
|-----|-------|------------------------|
| 8   | 0.5   | Маленькие отступы      |
| 16  | 1     | Базовый размер текста  |
| 24  | 1.5   | H4                     |
| 32  | 2     | H3                     |
| 44  | 2.75  | H2                     |
| 52  | 3.25  | H1                     |

**Примеры использования:**

```scss
.hero__title {
  font-size: 2.75rem;      // 44px
  margin-bottom: 1.5rem;   // 24px
  padding: 2rem 1rem;      // 32px 16px
}

.container {
  max-width: 75rem;        // 1200px
  padding: 0 2rem;         // 0 32px
}

.button {
  padding: 1rem 2rem;      // 16px 32px
  border-radius: 0.5rem;   // 8px
}
```

**Почему НЕ em:**
- `em` - относительно родительского элемента (вложенность усложняет)
- `rem` - всегда относительно корневого элемента (проще считать)

---

## HOVER ЭФФЕКТЫ

### Типы hover эффектов в проекте

### 1. Кнопки

**Primary кнопка:**

```scss
.btn-primary {
  background-color: $primary-color;
  color: $white;
  transition: all 0.3s ease;
  
  &:hover {
    background-color: $primary-dark;      // Темнее цвет
    transform: translateY(-0.125rem);     // Поднимается вверх
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15); // Тень
  }
  
  &:active {
    transform: translateY(0);             // Возврат при клике
  }
}
```

**Анимация:**
1. Цвет меняется с оранжевого на тёмно-оранжевый
2. Кнопка поднимается на 2px вверх
3. Появляется тень для эффекта "парения"
4. При клике - возврат в исходное положение

### 2. Ссылки навигации

**Подчёркивание при hover:**

```scss
.header__link {
  position: relative;
  
  // Создаём линию через псевдоэлемент
  &::after {
    content: '';
    position: absolute;
    bottom: -0.25rem;
    left: 0;
    width: 0;                    // Начальная ширина 0
    height: 0.125rem;
    background-color: $primary-color;
    transition: width 0.3s ease; // Анимация ширины
  }
  
  &:hover {
    color: $primary-color;
    
    &::after {
      width: 100%;               // Линия растягивается
    }
  }
}
```

### 3. Карточки

**Эффект поднятия:**

```scss
.meal-card {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  
  &:hover {
    transform: translateY(-0.5rem);        // Поднятие на 8px
    box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175); // Большая тень
  }
}
```

### 4. Аватарки клиентов

**Увеличение с изменением z-index:**

```scss
.hero__customer-avatar {
  transition: transform 0.3s ease, z-index 0s;
  
  &:hover {
    transform: scale(1.15);      // Увеличение на 15%
    z-index: 10;                 // Выше других
    border-color: $primary-color; // Акцентный цвет границы
  }
}
```

### 5. Изображения блюд

**Плавное масштабирование:**

```scss
.meal__image-container {
  overflow: hidden;              // Обрезаем выходящее изображение
  
  img {
    transition: transform 0.5s ease;
    
    &:hover {
      transform: scale(1.1);     // Увеличение на 10%
    }
  }
}
```

---

## ДЕНЬ 1: HEADER И HERO

### Header Component

#### HTML Структура

**Семантическая разметка:**

```html
<header class="header" role="banner">
  <div class="container">
    <nav class="header__nav" role="navigation">
      <!-- Логотип -->
      <!-- Меню -->
      <!-- Мобильная кнопка -->
    </nav>
  </div>
</header>
```

**Роли ARIA:**
- `role="banner"` - определяет header как главную шапку
- `role="navigation"` - определяет навигацию
- `role="menubar"` - определяет меню

#### TypeScript Логика

**Ключевые методы:**

1. **toggleMobileMenu()** - переключение мобильного меню

```typescript
toggleMobileMenu(): void {
  this.isMobileMenuOpen = !this.isMobileMenuOpen;
  
  // Блокируем скролл когда меню открыто
  if (this.isMobileMenuOpen) {
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
}
```

**Почему блокируем скролл:**
- На мобильных устройствах меню полноэкранное
- Скролл основной страницы мешает UX
- После закрытия - восстанавливаем скролл

2. **@HostListener для скролла** - отслеживание прокрутки

```typescript
@HostListener('window:scroll', ['$event'])
onWindowScroll(): void {
  const scrollPosition = window.pageYOffset;
  this.isScrolled = scrollPosition > 100;
}
```

**Что происходит:**
- Слушаем событие `scroll` на window
- Получаем позицию прокрутки
- Если > 100px - добавляем класс `.scrolled`
- Класс меняет стили header (фон, тень)

#### SCSS Стили

**Sticky позиционирование:**

```scss
.header {
  position: fixed;           // Фиксированное
  top: 0;
  left: 0;
  right: 0;
  z-index: 1020;            // Выше основного контента
  
  background-color: rgba($primary-light, 0.95);
  backdrop-filter: blur(10px); // Размытие фона
  
  transition: all 0.3s ease;
}
```

**Анимация бургер-меню:**

```scss
.header__mobile-toggle-icon {
  // Средняя линия
  background-color: $text-dark;
  
  // Верхняя линия
  &::before {
    top: -0.5rem;
  }
  
  // Нижняя линия
  &::after {
    bottom: -0.5rem;
  }
}

// При открытии меню - превращаем в X
&[aria-expanded="true"] {
  .header__mobile-icon {
    background-color: transparent; // Скрываем среднюю
    
    &::before {
      top: 0;
      transform: rotate(45deg);    // Поворот верхней
    }
    
    &::after {
      bottom: 0;
      transform: rotate(-45deg);   // Поворот нижней
    }
  }
}
```

### Hero Component

#### HTML Структура

**Grid layout:**

```html
<section class="hero">
  <div class="container">
    <div class="hero__grid">
      <!-- Левая часть: текст -->
      <div class="hero__content">
        <h1>Заголовок</h1>
        <p>Описание</p>
        <div class="hero__buttons">...</div>
        <div class="hero__customers">...</div>
      </div>
      
      <!-- Правая часть: изображение -->
      <div class="hero__image-box">
        <picture>
          <source srcset="hero.webp" type="image/webp">
          <img src="hero.png" alt="...">
        </picture>
      </div>
    </div>
  </div>
</section>
```

**Picture элемент:**

```html
<picture>
  <!-- WebP для современных браузеров -->
  <source srcset="hero.webp" type="image/webp" />
  
  <!-- PNG fallback для старых -->
  <img src="hero.png" alt="..." />
</picture>
```

**Преимущества:**
- WebP - на 30% меньше размер
- Автоматический fallback для старых браузеров
- Лучшая производительность

#### TypeScript Логика

**Анимация при загрузке:**

```typescript
ngOnInit(): void {
  this.animateOnLoad();
}

private animateOnLoad(): void {
  setTimeout(() => {
    const heroElement = document.querySelector('.hero');
    heroElement?.classList.add('hero--loaded');
  }, 100);
}
```

**Процесс:**
1. Компонент загружается (opacity: 0)
2. Через 100ms добавляется класс `.hero--loaded`
3. CSS transition делает плавное появление
4. Финальное состояние (opacity: 1)

#### SCSS Стили

**Grid layout:**

```scss
.hero__grid {
  display: grid;
  grid-template-columns: 1fr;     // Mobile: 1 колонка
  gap: 3rem;
  
  @media (min-width: 62em) {      // Desktop: 2 колонки
    grid-template-columns: 1fr 1fr;
    gap: 6rem;
  }
}
```

**Анимации:**

```scss
// Начальное состояние
.hero {
  opacity: 0;
  transform: translateY(2rem);
  transition: opacity 0.5s ease, transform 0.5s ease;
}

// Финальное состояние
.hero--loaded {
  opacity: 1;
  transform: translateY(0);
}

// Контент с задержкой
.hero__content {
  animation: slideUp 0.8s ease-out 0.2s both;
}

// Изображение с большей задержкой
.hero__image-box {
  animation: slideUp 0.8s ease-out 0.4s both;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(3rem);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
```

---

## ПРОИЗВОДИТЕЛЬНОСТЬ

### 1. Оптимизация изображений

**Форматы:**
- **WebP** - основной формат (меньше размер)
- **PNG/JPG** - fallback для старых браузеров

**Lazy loading:**

```html
<!-- Не загружаем сразу -->
<img loading="lazy" src="meal.jpg" alt="Блюдо">

<!-- Hero изображение - грузим сразу -->
<img loading="eager" src="hero.jpg" alt="Главное изображение">
```

**Правильные размеры:**

```html
<!-- Указываем ширину и высоту для предотвращения layout shift -->
<img 
  src="hero.jpg" 
  width="800" 
  height="600"
  alt="Hero image"
/>
```

### 2. CSS оптимизация

**will-change для анимаций:**

```scss
.hero__image {
  will-change: transform;  // Подсказка браузеру
}
```

**GPU ускорение:**

```scss
.card {
  transform: translateZ(0);  // Включаем GPU
}
```

### 3. Tree-shaking

Angular автоматически удаляет неиспользуемый код:

```typescript
// Импортируем только то, что нужно
import { Component } from '@angular/core';

// ❌ НЕ импортируем весь lodash
import * as _ from 'lodash';

// ✅ Импортируем только нужную функцию
import debounce from 'lodash/debounce';
```

---

## ACCESSIBILITY

### 1. Keyboard Navigation

**Tab навигация:**

```scss
// Видимый focus только при клавиатурной навигации
.button:focus-visible {
  outline: 3px solid $primary-color;
  outline-offset: 4px;
}
```

### 2. ARIA атрибуты

```html
<!-- Состояние кнопки -->
<button 
  [attr.aria-expanded]="isMenuOpen"
  aria-label="Переключить меню"
>

<!-- Скрытый текст для screen readers -->
<span class="visually-hidden">
  Главная навигация
</span>
```

### 3. Contrast ratio

**Минимальные требования WCAG:**
- Обычный текст: 4.5:1
- Крупный текст: 3:1
- UI элементы: 3:1

**Наши цвета:**
```scss
// Текст на белом: #333 on #FFF = 12.63:1 ✅
// Primary на белом: #e67e22 on #FFF = 3.57:1 ✅
```

### 4. Reduced Motion

```scss
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

---

## ЗАКЛЮЧЕНИЕ

### Итоги День 1

**Выполнено:**
- ✅ Header с sticky навигацией
- ✅ Адаптивное мобильное меню
- ✅ Hero секция с grid layout
- ✅ Анимации появления
- ✅ SEO оптимизация
- ✅ Использование только rem
- ✅ Hover эффекты
- ✅ Accessibility

**Следующие шаги:**
- День 2: Featured-in и How It Works секции
- День 3: Meals секция
- День 4: Testimonials и Gallery
- День 5: Pricing, CTA и Footer

---

## КОНТРОЛЬНЫЕ ВОПРОСЫ ДЛЯ ПРЕЗЕНТАЦИИ

1. **Почему используем standalone компоненты?**
   - Меньше boilerplate кода
   - Лучше tree-shaking
   - Проще структура проекта

2. **Зачем нужны rem единицы?**
   - Масштабируемость
   - Accessibility
   - Консистентность

3. **Как работает sticky header?**
   - position: fixed
   - @HostListener отслеживает скролл
   - Класс .scrolled меняет стили

4. **Какие SEO техники применены?**
   - Семантический HTML
   - Meta теги
   - Alt теги для изображений
   - Правильная иерархия заголовков

5. **Как обеспечена безопасность?**
   - Angular sanitization
   - CSP заголовки
   - Валидация форм
   - HTTPS only

---

**Автор:** [Ваше имя]
**Дата:** 09.02.2026
**Версия:** 1.0
